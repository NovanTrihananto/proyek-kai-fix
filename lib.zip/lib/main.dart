import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'routes.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/noisense/noisense_screen.dart';
import 'screens/noisense/scan_qr_screen.dart';
import 'screens/noisense/location_info_screen.dart';
import 'screens/feedback_screen.dart';
import 'screens/panduan_screen.dart';
import 'screens/sarana_prasarana/sarana_screen.dart';
import 'constants/colors.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
      .then((_) {
    runApp(MyApp());
  });
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Aplikasi Informasi',
      theme: ThemeData(
        primaryColor: AppColors.primary,
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Poppins',
        appBarTheme: AppBarTheme(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      ),
      home: SplashScreen(),
      routes: {
        Routes.splash: (context) => SplashScreen(),
        Routes.login: (context) => LoginScreen(),
        Routes.dashboard: (context) => DashboardScreen(),
        Routes.profile: (context) => ProfileScreen(),
        Routes.noisense: (context) => NoisenseScreen(),
        Routes.scanQR: (context) => ScanQRScreen(),
        Routes.locationInfo: (context) => MapScreen(),
        Routes.feedback: (context) => FeedbackScreen(),
        Routes.panduan: (context) => PanduanScreen(),
        Routes.saranaPrasarana: (context) => SaranaPrasaranaScreen(),
      },
    );
  }
}