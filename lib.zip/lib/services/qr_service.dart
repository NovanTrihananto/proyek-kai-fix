import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'dart:convert';

class QRService {
  // Scan a QR code and return the result
  Future<String?> scanQR() async {
    try {
      final barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
        '#FF6666', // Color for the scan line
        'Batal', // Cancel button text
        true, // Show flash icon
        ScanMode.QR, // Scan mode
      );

      // If user canceled the scan
      if (barcodeScanRes == '-1') {
        return null;
      }

      return barcodeScanRes;
    } on PlatformException {
      return null;
    } catch (e) {
      print('QR scan error: $e');
      return null;
    }
  }

  // Parse the QR code and extract location data
  Map<String, dynamic>? parseLocationQR(String qrData) {
    try {
      // Assuming the QR contains JSON data about a location
      final Map<String, dynamic> data = Map<String, dynamic>.from(
        Map.castFrom(
          Map<dynamic, dynamic>.from({
            'name': 'Lokasi tidak ditemukan',
            'address': 'Alamat tidak tersedia',
            'description': 'Informasi tidak tersedia',
            'latitude': 0.0,
            'longitude': 0.0,
          }),
        ),
      );

      // Try to parse the QR data
      try {
        final parsedData = jsonDecode(qrData);
        if (parsedData is Map<String, dynamic>) {
          data.addAll(parsedData);
        }
      } catch (e) {
        print('QR parse error: $e');
        // If not valid JSON, just use the raw data as name
        data['name'] = qrData;
      }

      return data;
    } catch (e) {
      print('QR parse error: $e');
      return null;
    }
  }
}
