class Routes {
  static const String splash = '/splash';
  static const String login = '/login';
  static const String dashboard = '/dashboard';
  static const String profile = '/profile';
  static const String noisense = '/noisense';
  static const String scanQR = '/scan_qr';
  static const String locationInfo = '/location_info';
  static const String feedback = '/feedback';
  static const String panduan = '/panduan';
  static const String saranaPrasarana = '/sarana_prasarana';
  static const String locationInfoSarana = '/location_info_sarana';
}