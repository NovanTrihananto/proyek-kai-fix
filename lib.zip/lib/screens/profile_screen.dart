import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../constants/colors.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  Future<Map<String, String>> _getUserInfo() async {
  final user = await AuthService().getCurrentUser();
  if (user == null) {
    return {
      'username': 'Tidak tersedia',
      'instansi': 'Tidak diketahui',
    };
  }

  return {
    'username': user.username,
    'instansi': user.instansi,
    };
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil Pengguna'),
        backgroundColor: AppColors.primary,
      ),
      body: FutureBuilder<Map<String, String>>(
        future: _getUserInfo(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final user = snapshot.data!;
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Nama Pengguna:', style: TextStyle(fontWeight: FontWeight.bold)),
                Text(user['username']!),
                const SizedBox(height: 20),
                Text('Instansi:', style: TextStyle(fontWeight: FontWeight.bold)),
                Text(user['instansi']!),
              ],
            ),
          );
        },
      ),
    );
  }
}
