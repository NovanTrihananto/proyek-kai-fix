import 'package:flutter/material.dart';
import '../../constants/colors.dart';
import '../../constants/string.dart';
import '../../routes.dart';
import '../../services/qr_service.dart';

class ScanQRScreen extends StatefulWidget {
  @override
  _ScanQRScreenState createState() => _ScanQRScreenState();
}

class _ScanQRScreenState extends State<ScanQRScreen> {
  final QRService _qrService = QRService();
  bool _isScanning = false;
  
  @override
  void initState() {
    super.initState();
    // Start scanning when the screen loads
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scanQR();
    });
  }

  Future<void> _scanQR() async {
    setState(() {
      _isScanning = true;
    });

    try {
      final qrData = await _qrService.scanQR();
      
      setState(() {
        _isScanning = false;
      });
      
      if (qrData != null) {
        // Parse the QR data to get location information
        final locationData = _qrService.parseLocationQR(qrData);
        
        if (locationData != null) {
          // Navigate to location info screen and pass the data
          Navigator.pushReplacementNamed(
            context,
            Routes.locationInfo,
            arguments: locationData,
          );
        } else {
          _showError('Format QR tidak valid');
        }
      } else {
        // User canceled the scan
        Navigator.pop(context);
      }
    } catch (e) {
      setState(() {
        _isScanning = false;
      });
      _showError('Terjadi kesalahan saat memindai QR');
    }
  }
  
  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppColors.error,
      ),
    );
    // Go back after showing error
    Future.delayed(Duration(seconds: 2), () {
      Navigator.pop(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Scan QR Code'),
      ),
      body: Center(
        child: _isScanning
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 24),
                  Text(
                    'Memindai QR Code...',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Arahkan kamera ke QR Code',
                    style: TextStyle(
                      fontSize: 16,
                      color: AppColors.textLight,
                    ),
                  ),
                ],
              )
            : ElevatedButton.icon(
                onPressed: _scanQR,
                icon: Icon(Icons.qr_code_scanner),
                label: Text('Pindai Ulang'),
              ),
      ),
    );
  }
}